# HyTEA

Hyperparameter Tuning using Evolutionary Algorithms

Contributors:

- Thomas Blom
- Josef Hamelink
- Levi Peeters
- Shreyansh Sharma

## Description

HyTEA is a hyperparameter tuning library that uses evolutionary algorithms to find the optimal hyperparameters (including architecture) for a given game.
